import cv2
import numpy as np
#import pandas as pd
import imutils
import os
import re
import pandas as pd
import matplotlib.pyplot as plt


video = "D:/gametest.mp4"
'''
# Create a VideoCapture object and read from input file
# If the input is the camera, pass 0 instead of the video file name
cap = cv2.VideoCapture(video)
cnt=0

# Check if camera opened successfully
if (cap.isOpened()== False): 
  print("Error opening video stream or file")

ret,first_frame = cap.read()

# Read until video is completed
while(cap.isOpened()):
    
  # Capture frame-by-frame
  ret, frame = cap.read()
     
  if ret == True:
    
    #removing scorecard
    roi = cv2.resize(frame,(720,480))
    
    #cropping center of an image
    thresh=225
    end = roi.shape[1] - thresh
    roi = roi[:,thresh:end]
    
    cv2.imshow("image",roi)
    # Press Q on keyboard to  exit
    if cv2.waitKey(100) & 0xFF == ord('q'):
      break

    cv2.imwrite("D:/gmt/pic%d.jpg"%cnt,roi)
    cnt=cnt+1

  # Break the loop
  else: 
    break

cv2.destroyAllWindows()    
'''
frames = os.listdir('D:/gmt/')
frames.sort(key=lambda f: int(re.sub('\D', '', f)))

images=[]

for i in frames:
    img = cv2.imread('D:/gmt/'+i)
    img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    img = cv2.GaussianBlur(img,(25,25),0)
    images.append(img)
    
images=np.array(images)

nonzero=[]
for i in range((len(images)-1)):
    
    mask = cv2.absdiff(images[i],images[i+1])
    _ , mask = cv2.threshold(mask, 50, 255, cv2.THRESH_BINARY)
    num = np.count_nonzero((mask.ravel()))
    nonzero.append(num)
    
    
x = np.arange(0,len(images)-1)
y = nonzero

#plt.figure(figsize=(20,4))
#plt.scatter(x,y)


threshold = 6000
scene_change_idx = 0
for i in range(len(images)-1):
    if(nonzero[i]>threshold): 
        scene_change_idx = i
        break
if scene_change_idx:
    frames = frames[:(scene_change_idx+1)]

img= cv2.imread('D:/gmt/' + frames[137])
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
gray = cv2.GaussianBlur(gray,(15,15),0)

plt.figure(figsize=(5,10))
plt.imshow(gray,cmap='gray')

_ , mask = cv2.threshold(gray, 180, 200, cv2.THRESH_BINARY)

plt.figure(figsize=(5,10))
plt.imshow(mask,cmap='gray')


contours,_ = cv2.findContours(mask, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
img_copy = np.copy(gray)
cv2.drawContours(img_copy, contours, -1, (0,255,0), 3)
plt.imshow(img_copy, cmap='gray')


patch = 'D:/gmtp/'
num=20
cnt=0
for i in range(len(contours)):
    x,y,w,h = cv2.boundingRect(contours[i])
    
    numer=min([w,h])
    denom=max([w,h])
    ratio=numer/denom

    if(x>=num and y>=num):
        xmin, ymin= x-num, y-num
        xmax, ymax= x+w+num, y+h+num
    else:
        xmin, ymin=x, y
        xmax, ymax=x+w, y+h

    if(ratio>=0.5 and ((w<=10) and (h<=10)) ):    
        #print(cnt,x,y,w,h,ratio)
        cv2.imwrite(patch+str(cnt)+".png",img[ymin:ymax,xmin:xmax])
        cnt=cnt+1
    
    df = pd.DataFrame(columns=['frame','x','y','w','h'])
    if(ratio>=0.5):    
        #print(cnt,x,y,w,h,ratio)
        df.loc[cnt,'frame'] = i
        df.loc[cnt,'x']=x
        df.loc[cnt,'y']=y
        df.loc[cnt,'w']=w
        df.loc[cnt,'h']=h
        
        cv2.imwrite(patch+str(cnt)+".png",img[ymin:ymax,xmin:xmax])
        cnt=cnt+1
        

#ball_df.dropna(inplace=True)
#print(df)


        
    